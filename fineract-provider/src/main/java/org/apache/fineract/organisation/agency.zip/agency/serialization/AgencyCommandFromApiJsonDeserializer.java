/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.fineract.organisation.agency.serialization;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.apache.fineract.infrastructure.core.data.ApiParameterError;
import org.apache.fineract.infrastructure.core.data.DataValidatorBuilder;
import org.apache.fineract.infrastructure.core.exception.InvalidJsonException;
import org.apache.fineract.infrastructure.core.exception.PlatformApiDataValidationException;
import org.apache.fineract.infrastructure.core.serialization.FromJsonHelper;
import org.apache.fineract.organisation.agency.service.AgencyConstants;
import org.apache.fineract.organisation.agency.service.AgencyConstants.AgencySupportedParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Deserializer of JSON for agency API.
 */
@Component
public final class AgencyCommandFromApiJsonDeserializer {

    /**
     * The parameters supported for this command.
     */
    private final Set<String> supportedParameters = AgencyConstants.AgencySupportedParameters.getAllValues();

    private final FromJsonHelper fromApiJsonHelper;

    @Autowired
    public AgencyCommandFromApiJsonDeserializer(final FromJsonHelper fromApiJsonHelper) {
        this.fromApiJsonHelper = fromApiJsonHelper;
    }

    public void validateForCreate(final String json) {
        if (StringUtils.isBlank(json)) {
            throw new InvalidJsonException();
        }

        final Type typeOfMap = new TypeToken<Map<String, Object>>() {}.getType();
        this.fromApiJsonHelper.checkForUnsupportedParameters(typeOfMap, json, this.supportedParameters);

        final List<ApiParameterError> dataValidationErrors = new ArrayList<>();
        final DataValidatorBuilder baseDataValidator = new DataValidatorBuilder(dataValidationErrors)
                .resource(AgencyConstants.AGENCY_RESOURCE_NAME);

        final JsonElement element = this.fromApiJsonHelper.parse(json);

        final String name = this.fromApiJsonHelper.extractStringNamed(AgencySupportedParameters.NAME.getValue(), element);
        baseDataValidator.reset().parameter(AgencySupportedParameters.NAME.getValue()).value(name).notBlank().notExceedingLengthOf(60);

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.OFFICE_PARENT_ID.getValue(), element)) {
            final Long parentId = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.OFFICE_PARENT_ID.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.OFFICE_PARENT_ID.getValue()).value(parentId).notNull()
                    .integerGreaterThanZero();
        }

        final String address = this.fromApiJsonHelper.extractStringNamed(AgencySupportedParameters.ADDRESS.getValue(), element);
        baseDataValidator.reset().parameter(AgencySupportedParameters.ADDRESS.getValue()).value(address).notBlank()
                .notExceedingLengthOf(250);

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.CITY_ID.getValue(), element)) {
            final Long cityId = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.CITY_ID.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.CITY_ID.getValue()).value(cityId).ignoreIfNull();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.STATE_ID.getValue(), element)) {
            final Long stateId = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.STATE_ID.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.STATE_ID.getValue()).value(stateId).ignoreIfNull();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.COUNTRY_ID.getValue(), element)) {
            final Long countryId = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.COUNTRY_ID.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.COUNTRY_ID.getValue()).value(countryId).ignoreIfNull()
                    .integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.ENTITY_CODE.getValue(), element)) {
            final Long entityCode = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.ENTITY_CODE.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.ENTITY_CODE.getValue()).value(entityCode).notNull()
                    .integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.CURRENCY_CODE.getValue(), element)) {
            final Long currencyCode = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.CURRENCY_CODE.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.CURRENCY_CODE.getValue()).value(currencyCode).notNull()
                    .integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.AGENCY_TYPE.getValue(), element)) {
            final Long agencyType = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.AGENCY_TYPE.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.AGENCY_TYPE.getValue()).value(agencyType).notNull()
                    .integerGreaterThanZero();
        }

        final String phone = this.fromApiJsonHelper.extractStringNamed(AgencySupportedParameters.PHONE.getValue(), element);
        baseDataValidator.reset().parameter(AgencySupportedParameters.PHONE.getValue()).value(phone).ignoreIfNull()
                .notExceedingLengthOf(20);

        final String telex = this.fromApiJsonHelper.extractStringNamed(AgencySupportedParameters.TELEX.getValue(), element);
        baseDataValidator.reset().parameter(AgencySupportedParameters.TELEX.getValue()).value(telex).ignoreIfNull()
                .notExceedingLengthOf(50);

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.LABOUR_DAY_FROM.getValue(), element)) {
            final Long labourDayFrom = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.LABOUR_DAY_FROM.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.LABOUR_DAY_FROM.getValue()).value(labourDayFrom).ignoreIfNull()
                    .integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.LABOUR_DAY_TO.getValue(), element)) {
            final Long labourDayTo = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.LABOUR_DAY_TO.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.LABOUR_DAY_TO.getValue()).value(labourDayTo).ignoreIfNull()
                    .integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.OPEN_HOUR_MORNING.getValue(), element)) {
            final LocalTime openHourMorning = this.fromApiJsonHelper
                    .extractLocalTimeNamed(AgencySupportedParameters.OPEN_HOUR_MORNING.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.OPEN_HOUR_MORNING.getValue()).value(openHourMorning)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.OPEN_HOUR_AFTERNOON.getValue(), element)) {
            final LocalTime openHourAfternoon = this.fromApiJsonHelper
                    .extractLocalTimeNamed(AgencySupportedParameters.OPEN_HOUR_AFTERNOON.getValue(), element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.OPEN_HOUR_AFTERNOON.getValue()).value(openHourAfternoon)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.FINANCIAL_YEAR_FROM.getValue(), element)) {
            final Long financialYearFrom = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.FINANCIAL_YEAR_FROM.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.FINANCIAL_YEAR_FROM.getValue()).value(financialYearFrom)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.FINANCIAL_YEAR_TO.getValue(), element)) {
            final Long financialYearTo = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.FINANCIAL_YEAR_TO.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.FINANCIAL_YEAR_TO.getValue()).value(financialYearTo)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.NON_BUSINESS_DAY1.getValue(), element)) {
            final Long nonBusinessDay1 = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.NON_BUSINESS_DAY1.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.NON_BUSINESS_DAY1.getValue()).value(nonBusinessDay1)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.NON_BUSINESS_DAY2.getValue(), element)) {
            final Long nonBusinessDay2 = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.NON_BUSINESS_DAY2.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.NON_BUSINESS_DAY2.getValue()).value(nonBusinessDay2)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.HALF_BUSINESS_DAY1.getValue(), element)) {
            final Long halfBusinessDay1 = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.HALF_BUSINESS_DAY1.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.HALF_BUSINESS_DAY1.getValue()).value(halfBusinessDay1)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists(AgencySupportedParameters.HALF_BUSINESS_DAY2.getValue(), element)) {
            final Long halfBusinessDay2 = this.fromApiJsonHelper.extractLongNamed(AgencySupportedParameters.HALF_BUSINESS_DAY2.getValue(),
                    element);
            baseDataValidator.reset().parameter(AgencySupportedParameters.HALF_BUSINESS_DAY2.getValue()).value(halfBusinessDay2)
                    .ignoreIfNull().integerGreaterThanZero();
        }

        throwExceptionIfValidationWarningsExist(dataValidationErrors);
    }

    private void throwExceptionIfValidationWarningsExist(final List<ApiParameterError> dataValidationErrors) {
        if (!dataValidationErrors.isEmpty()) {
            throw new PlatformApiDataValidationException("validation.msg.validation.errors.exist", "Validation errors exist.",
                    dataValidationErrors);
        }
    }

    public void validateForUpdate(final String json) {
        if (StringUtils.isBlank(json)) {
            throw new InvalidJsonException();
        }

        final Type typeOfMap = new TypeToken<Map<String, Object>>() {}.getType();
        this.fromApiJsonHelper.checkForUnsupportedParameters(typeOfMap, json, this.supportedParameters);

        final List<ApiParameterError> dataValidationErrors = new ArrayList<>();
        final DataValidatorBuilder baseDataValidator = new DataValidatorBuilder(dataValidationErrors).resource("office");

        final JsonElement element = this.fromApiJsonHelper.parse(json);

        final String name = this.fromApiJsonHelper.extractStringNamed("name", element);
        baseDataValidator.reset().parameter("name").value(name).notBlank().notExceedingLengthOf(60);

        if (this.fromApiJsonHelper.parameterExists("parentId", element)) {
            final Long parentId = this.fromApiJsonHelper.extractLongNamed("parentId", element);
            baseDataValidator.reset().parameter("parentId").value(parentId).notNull().integerGreaterThanZero();
        }

        final String address = this.fromApiJsonHelper.extractStringNamed("address", element);
        baseDataValidator.reset().parameter("address").value(address).notBlank().notExceedingLengthOf(250);

        if (this.fromApiJsonHelper.parameterExists("cityId", element)) {
            final Long cityId = this.fromApiJsonHelper.extractLongNamed("cityId", element);
            baseDataValidator.reset().parameter("cityId").value(cityId).ignoreIfNull();
        }

        if (this.fromApiJsonHelper.parameterExists("stateId", element)) {
            final Long stateId = this.fromApiJsonHelper.extractLongNamed("stateId", element);
            baseDataValidator.reset().parameter("stateId").value(stateId).ignoreIfNull();
        }

        if (this.fromApiJsonHelper.parameterExists("countryId", element)) {
            final Long countryId = this.fromApiJsonHelper.extractLongNamed("countryId", element);
            baseDataValidator.reset().parameter("countryId").value(countryId).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("entityCode", element)) {
            final Long entityCode = this.fromApiJsonHelper.extractLongNamed("entityCode", element);
            baseDataValidator.reset().parameter("entityCode").value(entityCode).notNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("currencyCode", element)) {
            final Long currencyCode = this.fromApiJsonHelper.extractLongNamed("currencyCode", element);
            baseDataValidator.reset().parameter("currencyCode").value(currencyCode).notNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("agencyType", element)) {
            final Long agencyType = this.fromApiJsonHelper.extractLongNamed("agencyType", element);
            baseDataValidator.reset().parameter("agencyType").value(agencyType).notNull().integerGreaterThanZero();
        }

        final String phone = this.fromApiJsonHelper.extractStringNamed("phone", element);
        baseDataValidator.reset().parameter("phone").value(phone).ignoreIfNull().notExceedingLengthOf(20);

        final String telex = this.fromApiJsonHelper.extractStringNamed("telex", element);
        baseDataValidator.reset().parameter("telex").value(telex).ignoreIfNull().notExceedingLengthOf(50);

        if (this.fromApiJsonHelper.parameterExists("labourDayFrom", element)) {
            final Long labourDayFrom = this.fromApiJsonHelper.extractLongNamed("labourDayFrom", element);
            baseDataValidator.reset().parameter("labourDayFrom").value(labourDayFrom).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("labourDayTo", element)) {
            final Long labourDayTo = this.fromApiJsonHelper.extractLongNamed("labourDayTo", element);
            baseDataValidator.reset().parameter("labourDayTo").value(labourDayTo).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("openHourMorning", element)) {
            final LocalTime openHourMorning = this.fromApiJsonHelper.extractLocalTimeNamed("openHourMorning", element);
            baseDataValidator.reset().parameter("openHourMorning").value(openHourMorning).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("openHourAfternoon", element)) {
            final LocalTime openHourAfternoon = this.fromApiJsonHelper.extractLocalTimeNamed("openHourAfternoon", element);
            baseDataValidator.reset().parameter("openHourAfternoon").value(openHourAfternoon).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("financialYearFrom", element)) {
            final Long financialYearFrom = this.fromApiJsonHelper.extractLongNamed("financialYearFrom", element);
            baseDataValidator.reset().parameter("financialYearFrom").value(financialYearFrom).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("financialYearTo", element)) {
            final Long financialYearTo = this.fromApiJsonHelper.extractLongNamed("financialYearTo", element);
            baseDataValidator.reset().parameter("financialYearTo").value(financialYearTo).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("nonBusinessDay1", element)) {
            final Long nonBusinessDay1 = this.fromApiJsonHelper.extractLongNamed("nonBusinessDay1", element);
            baseDataValidator.reset().parameter("nonBusinessDay1").value(nonBusinessDay1).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("nonBusinessDay2", element)) {
            final Long nonBusinessDay2 = this.fromApiJsonHelper.extractLongNamed("nonBusinessDay2", element);
            baseDataValidator.reset().parameter("nonBusinessDay2").value(nonBusinessDay2).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("halfBusinessDay1", element)) {
            final Long halfBusinessDay1 = this.fromApiJsonHelper.extractLongNamed("halfBusinessDay1", element);
            baseDataValidator.reset().parameter("halfBusinessDay1").value(halfBusinessDay1).ignoreIfNull().integerGreaterThanZero();
        }

        if (this.fromApiJsonHelper.parameterExists("halfBusinessDay2", element)) {
            final Long halfBusinessDay2 = this.fromApiJsonHelper.extractLongNamed("halfBusinessDay2", element);
            baseDataValidator.reset().parameter("halfBusinessDay2").value(halfBusinessDay2).ignoreIfNull().integerGreaterThanZero();
        }

        throwExceptionIfValidationWarningsExist(dataValidationErrors);
    }
}
